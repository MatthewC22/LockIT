


import Register



Register.registerScreen.showRegisterWindow()


